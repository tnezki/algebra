Algebra 1 Portfolio Pilot - NWEA baseline + printable student reports

Open portfolio_state/index.html for the teacher dashboard.
Printable student report: student_reports/algebra1_portfolio_pilot_nwea_student_reports.pdf
The PDF is sorted by 3rd hour then 6th hour, alphabetically within each period. Each student receives exactly 2 pages so duplex printing yields one front/back sheet per student.

NWEA source term: Spring 2025-26. It is treated as prior-year context only and is not converted into a Portfolio proficiency status or grade.
Student IDs are intentionally omitted from the normalized portfolio data and the PDF.
The 6th-1 CSV was verified as a duplicate subset of the full 6th-hour export and was not double-counted.
