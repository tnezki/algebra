# NWEA baseline

Source term: Spring 2025-26. This is treated as a prior-year baseline for the 2026-27 Algebra 1 portfolio pilot.

The normalized file intentionally omits Student ID. NWEA results provide broad context only; they are not automatically converted into Portfolio proficiency levels or grades.
The uploaded 6th-1 CSV was verified as a duplicate 16-student subset of the full 6th-hour export and was not separately imported.
