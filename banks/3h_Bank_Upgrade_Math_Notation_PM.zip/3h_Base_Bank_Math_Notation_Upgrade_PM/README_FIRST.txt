3h — Mathematical Notation & Expression Hygiene Upgrade v1.1

Use:
  current Framework + finalized Unit Bank + this PM ZIP

Prompt:
  Carefully read PM and Run.

Run after 3g.
